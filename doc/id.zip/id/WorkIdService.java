package com.demo.id;

import com.demo.common.enums.RespCodeEnums;
import com.google.common.base.Splitter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * create table work_id_info
 * (
 * work_id     int         not null comment '节点id',
 * app_name    varchar(50) not null comment '应用名称',
 * update_time bigint      not null comment '更新时间',
 * primary key (work_id, app_name)
 * )
 * comment '节点id信息';
 *
 * @Date: 2023-08-26 10:03
 */
@Component
public class WorkIdService implements InitializingBean {
    
    private final Logger logger = LoggerFactory.getLogger(getClass());
    
    /** 当前work_id */
    private Long WORK_ID = null;
    
    /** work_id最后一次更新时间 */
    private Long LAST_UPDATE_TIME = null;
    
    /** 同一个应用的work_id最大值 */
    private static final int MAX_WORK_ID = 1023;
    
    /** 获取work_id时的重试次数 */
    private static final int MAX_TRY_TIMES = 3;
    
    /** work_id重复使用的最小时间间隔，在此时间段内，不允许重复使用 */
    private static final long REUSE_INTERVAL_TIME = 1000L * 60 * 60;
    
    private static final String INSERT_WORK_ID_SQL = "insert into work_id_info (work_id, app_name, update_time) values (?, ?, ?)";
    private static final String SELECT_WORK_ID_SQL = "select ifnull(max(work_id), -1) from work_id_info where app_name = ?";
    private static final String SELECT_MIN_TIME_WORK_ID_SQL = "select concat(work_id, '-', update_time) from work_id_info where app_name = ? order by update_time limit 1";
    private static final String UPDATE_WORK_ID_SQL = "update work_id_info set update_time = ? where app_name = ? and work_id = ? and update_time = ?";
    private static final String NOW_TIME_SQL = "select now()";
    
    private static final Object lock = new Object();
    
    @Value("${spring.application.name}")
    private String appName;
    
    private JdbcTemplate jdbcTemplate;
    
    private final DataSource dataSource;
    
    @Override
    public void afterPropertiesSet() {
        jdbcTemplate = new JdbcTemplate(dataSource);
        this.refreshTask();
    }
    
    public WorkIdService(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    
    public Long getWorkId() {
        if (WORK_ID != null) {
            return WORK_ID;
        }
        
        synchronized (lock) {
            if (WORK_ID != null) {
                return WORK_ID;
            }
            
            WORK_ID = doGetWorkId();
            logger.info("WORK_ID = " + WORK_ID);
            return WORK_ID;
        }
    }
    
    
    public Long doGetWorkId() {
        // 查询work_id_info表最大的work_id，如果不存在则返回0，然后判断最大值是否大于1024，如果大于1024 则从0开始，否则从最大值+1开始，写入work_id_info表，请给出提示代码
        Long maxWorkId = jdbcTemplate.queryForObject(SELECT_WORK_ID_SQL, Long.class, appName);
        if (maxWorkId == null) {
            throw RespCodeEnums.WORK_ID_ERROR.newException();
        }
        
        int runTimes = 0;
        while (runTimes < MAX_TRY_TIMES) {
            runTimes++;
            
            long nextWorkId = maxWorkId + 1;
            if (nextWorkId > MAX_WORK_ID) {
                // 从最小值开始
                return this.getExistWorkId();
            }
            
            try {
                Long currTime = this.getCurrTime();
                int res = jdbcTemplate.update(INSERT_WORK_ID_SQL, nextWorkId, appName, currTime);
                if (res == 1) {
                    LAST_UPDATE_TIME = currTime;
                    return nextWorkId;
                }
            } catch (DuplicateKeyException e) {
                // 主键重复，进行下一轮
                maxWorkId = nextWorkId;
            }
        }
        
        throw RespCodeEnums.WORK_ID_ERROR.newException();
    }
    
    private Long getExistWorkId() {
        int runTimes = 0;
        while (runTimes < MAX_TRY_TIMES) {
            runTimes++;
            
            String minWorkIdData = jdbcTemplate.queryForObject(SELECT_MIN_TIME_WORK_ID_SQL, String.class, appName);
            if (StringUtils.isBlank(minWorkIdData)) {
                throw RespCodeEnums.WORK_ID_ERROR.newException();
            }
            
            List<String> dataList = Splitter.on("-").splitToList(minWorkIdData);
            long workId = Long.parseLong(dataList.get(0));
            long minUpdateTime = Long.parseLong(dataList.get(1));
            
            Long currTime = this.getCurrTime();
            
            if (currTime - minUpdateTime > REUSE_INTERVAL_TIME) {
                int res = jdbcTemplate.update(UPDATE_WORK_ID_SQL, currTime, appName, workId, minUpdateTime);
                if (res == 1) {
                    LAST_UPDATE_TIME = currTime;
                    return workId;
                }
            }
        }
        
        throw RespCodeEnums.WORK_ID_ERROR.newException();
    }
    
    private Long getCurrTime() {
        Timestamp timestamp = jdbcTemplate.queryForObject(NOW_TIME_SQL, Timestamp.class);
        if (timestamp == null) {
            return System.currentTimeMillis();
        }
        return timestamp.getTime();
    }
    
    public void refreshTask() {
        Executors.newScheduledThreadPool(1, thread -> {
            Thread t = new Thread(thread);
            t.setName("workid-task-");
            return t;
        }).scheduleAtFixedRate(() -> {
            if(WORK_ID == null){
                return;
            }
            
            try {
                
                Long currTime = this.getCurrTime();
                int res = jdbcTemplate.update(UPDATE_WORK_ID_SQL, currTime, appName, WORK_ID, LAST_UPDATE_TIME);
                if (res == 1) {
                    logger.info("刷新work_id时间...成功...");
                    LAST_UPDATE_TIME = currTime;
                    return;
                }
                logger.info("刷新work_id时间...失败...");
                // 按类型分别获取，此情况一般不存在，除非在 REUSE_INTERVAL_TIME 范围内同一个应用所有节点重启总次数大于 MAX_WORK_ID
                
            } catch (Exception e) {
                logger.error("刷新work_id时间异常", e);
            }
        }, 30, 30, TimeUnit.MINUTES);
        
    }
    
    
}
